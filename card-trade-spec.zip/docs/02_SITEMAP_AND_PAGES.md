# 02 - サイトマップ・ページ一覧

## 1. URL構造

### 公開ページ
```
/                          トップページ
/prices                    買取価格一覧
/flow                      買取の流れ
/assessment                オンライン査定フォーム
/assessment/thanks         査定送信完了
/shop                      ECショップ（商品一覧）
/shop/[id]                 商品詳細
/cart                      カート
/cart/order                注文フォーム
/cart/thanks               注文完了
/company                   会社概要
/legal                     特定商取引法に基づく表記
/contact                   お問い合わせ
/contact/thanks            送信完了
/news                      お知らせ一覧
/news/[id]                 お知らせ詳細
/privacy                   プライバシーポリシー
/login                     ログインページ
```

### 管理画面（認証必須）
```
/admin                     ダッシュボード
/admin/products            商品管理一覧
/admin/products/new        商品登録
/admin/products/[id]       商品編集
/admin/assessments         査定管理一覧
/admin/assessments/[id]    査定詳細
/admin/prices              買取価格管理
/admin/orders              注文管理一覧
/admin/orders/[id]         注文詳細
/admin/news                お知らせ管理
/admin/news/new            お知らせ作成
/admin/news/[id]           お知らせ編集
```

## 2. Next.js App Router ディレクトリ構造

```
src/
├── app/
│   ├── layout.tsx
│   ├── page.tsx                   トップ
│   ├── prices/page.tsx
│   ├── flow/page.tsx
│   ├── assessment/
│   │   ├── page.tsx
│   │   └── thanks/page.tsx
│   ├── shop/
│   │   ├── page.tsx
│   │   └── [id]/page.tsx
│   ├── cart/
│   │   ├── page.tsx
│   │   ├── order/page.tsx
│   │   └── thanks/page.tsx
│   ├── company/page.tsx
│   ├── legal/page.tsx
│   ├── contact/
│   │   ├── page.tsx
│   │   └── thanks/page.tsx
│   ├── news/
│   │   ├── page.tsx
│   │   └── [id]/page.tsx
│   ├── privacy/page.tsx
│   ├── login/page.tsx
│   ├── admin/
│   │   ├── layout.tsx
│   │   ├── page.tsx               ダッシュボード
│   │   ├── products/
│   │   ├── assessments/
│   │   ├── prices/
│   │   ├── orders/
│   │   └── news/
│   └── api/
│       ├── assessment/route.ts
│       ├── contact/route.ts
│       ├── order/route.ts
│       └── admin/prices/import/route.ts
├── components/
│   ├── ui/          共通UI
│   ├── layout/      ヘッダー・フッター
│   ├── home/        トップページ
│   ├── prices/      買取価格
│   ├── shop/        ショップ
│   ├── assessment/  査定
│   └── admin/       管理画面
├── lib/
│   ├── supabase/    クライアント設定
│   ├── types/       型定義
│   ├── utils/       ユーティリティ
│   └── hooks/       カスタムフック
└── styles/
    └── globals.css
```

## 3. ナビゲーション構造

### ヘッダー
ロゴ | 買取価格 | 買取の流れ | オンライン査定 | ショップ | 会社概要 | [無料査定ボタン]

### フッター（4カラム）
サービス / 会社情報 / サポート + 古物商許可表示

### 管理画面サイドバー
📊ダッシュボード / 📦商品 / 💰買取価格 / 📋査定 / 🛒注文 / 📢お知らせ / ←サイト / 🚪ログアウト
